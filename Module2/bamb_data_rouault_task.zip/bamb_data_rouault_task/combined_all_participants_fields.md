# Generated data fields

## `combined_all_participants.csv`

This file contains every row and the ordered union of every field from all source CSV files. Source fields appear first. Generated preprocessing and ACTOBS fields follow them. A source field missing from one participant file is blank for that file's rows. No source filename or source path is added to the CSV. `subj` is the anonymous participant ID and is suffixed only when separate files reuse the same ID. Rows excluded from the MAT files remain in the CSV and are identified by `actobs_included` and `actobs_exclusion_reason` (or their collision-safe generated names).

| # | Field | Origin | Type | Description | Notes |
| --- | --- | --- | --- | --- | --- |
| 1 | Unnamed: 0 | source CSV | integer | Index column already present in the source CSV export. | This field existed in the source. The script writes index=False and does not add another CSV index field. |
| 2 | index | source CSV | integer | Source row or event index recorded by the experiment. | Preserved from the source; blank for rows from input files that did not contain this field. |
| 3 | exp | source CSV | text or serialized value | Experiment or task implementation identifier. | Preserved from the source; blank for rows from input files that did not contain this field. |
| 4 | rule | source CSV | integer | Response-mapping rule used for the trial or block. | Preserved from the source; blank for rows from input files that did not contain this field. |
| 5 | subj | source CSV | integer-like numeric | Anonymous participant identifier. Reused IDs in separate files receive a suffix such as _2. | Source participant ID; separate files that reuse the same ID are made unique with _2, _3, and so on. |
| 6 | task | source CSV | integer | Task or experimental condition number. | Preserved from the source; blank for rows from input files that did not contain this field. |
| 7 | block_index | source CSV | integer | Block number from the source experiment. | Preserved from the source; blank for rows from input files that did not contain this field. |
| 8 | mu | source CSV | integer | Source stimulus-distribution location parameter. | Preserved from the source; blank for rows from input files that did not contain this field. |
| 9 | kappa | source CSV | number | Source stimulus-distribution concentration parameter. | Preserved from the source; blank for rows from input files that did not contain this field. |
| 10 | confidence_before | source CSV | integer-like numeric | Confidence state before observing the current sample sequence. | Preserved from the source; blank for rows from input files that did not contain this field. |
| 11 | confidence_after | source CSV | integer | Confidence state after observing the current sample sequence. | Preserved from the source; blank for rows from input files that did not contain this field. |
| 12 | response_before | source CSV | integer-like numeric | Response state before observing the current sample sequence. | Preserved from the source; blank for rows from input files that did not contain this field. |
| 13 | response_after | source CSV | integer | Response state after observing the current sample sequence. | Preserved from the source; blank for rows from input files that did not contain this field. |
| 14 | sequence_direction | source CSV | integer | Latent or generating direction/state of the current sequence. | Preserved from the source; blank for rows from input files that did not contain this field. |
| 15 | sequence_index | source CSV | integer | Source sequence or episode number within a block. | Preserved from the source; blank for rows from input files that did not contain this field. |
| 16 | sample_angle | source CSV | text or serialized value | Serialized vector of sample angles or stimulus values for the trial. | Preserved from the source; blank for rows from input files that did not contain this field. |
| 17 | sample_log_likelihood_ratio | source CSV | text or serialized value | Serialized vector of per-sample log-likelihood-ratio evidence. | Preserved from the source; blank for rows from input files that did not contain this field. |
| 18 | task_id | source CSV | integer | Task identifier recorded by the experiment runtime. | Preserved from the source; blank for rows from input files that did not contain this field. |
| 19 | rt | source CSV | number | Response time recorded by the experiment, in the source unit. | Preserved from the source; blank for rows from input files that did not contain this field. |
| 20 | correct | source CSV | integer | Correctness indicator recorded by the experiment. | Preserved from the source; blank for rows from input files that did not contain this field. |
| 21 | correct_response | source CSV | text or serialized value | Experiment-defined metadata describing the correct response option or key. | Preserved from the source; blank for rows from input files that did not contain this field. |
| 22 | rt_long | source CSV | boolean | Indicator that the response time met the experiment's long-RT criterion. | Preserved from the source; blank for rows from input files that did not contain this field. |
| 23 | trial_index | source CSV | integer | Trial number within the source block or task. | Preserved from the source; blank for rows from input files that did not contain this field. |
| 24 | episode_position | source CSV | integer | Position of the trial within the current latent-state episode. | Preserved from the source; blank for rows from input files that did not contain this field. |
| 25 | sequence_length | source CSV | integer | Number of samples contained in the current sequence. | Preserved from the source; blank for rows from input files that did not contain this field. |
| 26 | sequence_category | source CSV | integer | Experiment-defined category assigned to the sequence. | Preserved from the source; blank for rows from input files that did not contain this field. |
| 27 | key_press | source CSV | text or serialized value | Key recorded for the participant's response. | Preserved from the source; blank for rows from input files that did not contain this field. |
| 28 | block_type | source CSV | text or serialized value | Block label, such as practice or test. | Preserved from the source; blank for rows from input files that did not contain this field. |
| 29 | screenname | source CSV | text or serialized value | Screen or session label recorded by the experiment runtime. | Preserved from the source; blank for rows from input files that did not contain this field. |
| 30 | start_time | source CSV | text or serialized value | Experiment/session start timestamp as stored in the source data. | Preserved from the source; blank for rows from input files that did not contain this field. |
| 31 | design_seed | source CSV | integer | Random seed used to generate or select the experimental design. | Preserved from the source; blank for rows from input files that did not contain this field. |
| 32 | model_subj | generated | integer | Numeric participant number used in ACTOBS MAT filenames and runner subject lists. | Populated for every combined row. |
| 33 | actobs_included | generated | boolean | True when this source row is present in a generated ACTOBS MAT file. | Populated for every combined row. |
| 34 | actobs_exclusion_reason | generated | text | Reason a source row is not in a MAT file; blank for included rows. | Blank when 'actobs_included' is true. |
| 35 | blkind | generated | integer | Consecutive ACTOBS block number within the participant-task MAT file. | Blank when 'actobs_included' is false; see 'actobs_exclusion_reason'. |
| 36 | seqind | generated | integer | Consecutive observation number within blkind, starting at 1. | Blank when 'actobs_included' is false; see 'actobs_exclusion_reason'. |
| 37 | seqdir | generated | integer | Sequence direction coded as 1 or 2. | Blank when 'actobs_included' is false; see 'actobs_exclusion_reason'. |
| 38 | smpang | generated | JSON numeric array | Sample-angle vector serialized as a JSON numeric array. | Blank when 'actobs_included' is false; see 'actobs_exclusion_reason'. |
| 39 | smpllr | generated | JSON numeric array | Signed sample-LLR vector serialized as JSON; positive evidence favors response 1. | Blank when 'actobs_included' is false; see 'actobs_exclusion_reason'. |
| 40 | rbef | generated | integer | Response before the observation after ACTOBS response-code normalization. | Blank when 'actobs_included' is false; see 'actobs_exclusion_reason'. |
| 41 | raft | generated | integer | Response after the observation after ACTOBS response-code normalization. | Blank when 'actobs_included' is false; see 'actobs_exclusion_reason'. |
| 42 | cbef | generated | integer | Confidence before the observation in ACTOBS coding. | Blank when 'actobs_included' is false; see 'actobs_exclusion_reason'. |
| 43 | caft | generated | integer | Confidence after the observation in ACTOBS coding. | Blank when 'actobs_included' is false; see 'actobs_exclusion_reason'. |
| 44 | epinum | generated | integer | Derived latent-direction episode number within blkind. | Blank when 'actobs_included' is false; see 'actobs_exclusion_reason'. |
| 45 | seqpos | generated | integer | Derived position within the current latent-direction episode. | Blank when 'actobs_included' is false; see 'actobs_exclusion_reason'. |
| 46 | seqlen | generated | integer | Number of samples in smpang and smpllr. | Blank when 'actobs_included' is false; see 'actobs_exclusion_reason'. |
| 47 | seqllr | generated | number | Sum of the signed sample-LLR values in smpllr. | Blank when 'actobs_included' is false; see 'actobs_exclusion_reason'. |
| 48 | response_rule_mode | generated | text | Response-code transformation selected by preprocessing. | Populated for every combined row. |
| 49 | llr_sign_mode | generated | text | LLR sign transformation selected by preprocessing. | Populated for every combined row. |
| 50 | preprocessing_version | generated | text | Version of this preprocessing script. | Populated for every combined row. |

## Participant/task MAT files

Each MAT file contains a MATLAB `dat` structure. Optional source traceability fields are present only when the corresponding source field exists.

| MAT field | Description |
| --- | --- |
| blkind | Consecutive block number within the participant-task MAT file. |
| seqind | Consecutive observation number within blkind, starting at 1. |
| seqdir | Hidden sequence direction coded as 1 or 2. |
| smpang | MATLAB cell array containing the sample-angle vector for each retained row. |
| smpllr | MATLAB cell array containing sign-normalized sample LLR values; positive values favor response 1. |
| rbef | Response before the observation after ACTOBS response normalization. |
| raft | Response after the observation after ACTOBS response normalization. |
| cbef | Confidence before the observation. |
| caft | Confidence after the observation. |
| epinum | Derived hidden-direction episode number within the block. |
| seqpos | Derived position within the current hidden-direction episode. |
| seqlen | Number of samples in smpang and smpllr. |
| seqllr | Sum of the sign-normalized smpllr values. |
| source_subj | Unique anonymous participant ID after duplicate-ID suffixing. |
| model_subj | Numeric participant ID used in ACTOBS filenames and runner subject lists. |
| task | Task represented by the MAT file. |
| source_block_index | Original source block_index for each retained row. |
| source_trial_index | Original source trial_index for each retained row. |
| source_rule | Original response-mapping rule for each retained row. |
| source_sequence_index | Original sequence_index when that source field exists. |
| source_episode_position | Original episode_position when that source field exists. |
| response_rule_mode | Response-code transformation selected by preprocessing. |
| llr_sign_mode | LLR sign transformation selected by preprocessing. |
| preprocessing_version | Version of this preprocessing script. |
